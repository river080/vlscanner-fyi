from flask import Flask,request,jsonify
from flask_restful import Resource, Api
from flask_cors import CORS
import numpy as np
import pandas as pd
import openai
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.metrics import accuracy_score, classification_report
import pickle as pkl
import os
from sklearn.metrics import confusion_matrix
from dotenv import load_dotenv

app = Flask("XSSAI")
cors = CORS(app, origins=['http://localhost:3000'])
api = Api(app)

load_dotenv()

api_key = os.getenv("openai_key")
openai.api_key = api_key

@app.route('/xssai', methods=['POST'])
def aipredict():
    
    # Assigning dataset to a variable named df (dataframe)
    df = pd.read_csv("xss.csv")

    # Remove null columns
    df = df.iloc[:,:2]

    # Removing rows with null values
    df.dropna(inplace=True)

    # Remove duplicate rows
    df.drop_duplicates(inplace=True)

    # Preprocess the text data using CountVectorizer
    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(df['Sentence'])
    
    # Load the saved model from a file
    with open('clf.pkl', 'rb') as f:
        clf_loaded = pkl.load(f)
    
    # Get the JSON data from the request
    data = request.get_json()
    code = data.get('codeFragment')

    # Vectorize the user input
    X_query = vectorizer.transform([code])

    # Use the loaded model to make a prediction
    y_pred = clf_loaded.predict(X_query)

    result = y_pred[0]

    # Print the prediction
    if result == 1:
        print("The input is a XSS injected code.")
        
        # Send the vulnerable code to ChatGPT for recommendations
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-0301",
            messages=[
                {"role": "user", "content": f"There is a potential XSS vulnerability in this code: {code}. How to make it secure. You must provide the answer in minimum words. Do not include extra explanations, comments. Must provide the updated, more secure code. The answer must look like this, Recommendation: (your answer in minimum words), Code: (the secure code)"
                                 
                },
            ],
            max_tokens=45  # Adjust as needed
        )

        # Extract the recommendation and secure code from the ChatGPT response
        response_text = response['choices'][0]['message']['content']
        parts = response_text.split("Code:")

        if len(parts) == 2:
            recommendation = parts[0].strip()  # This should contain "Recommendation: Use input validation."
            secure_code = parts[1].strip()  # This should contain the secure code
        else:
            # Handle the case where the response doesn't follow the expected format
            recommendation = "Recommendation not found"
            secure_code = "Code not found"
        
        print(response_text)
        

        return jsonify({'result': 1, 'r': recommendation, 'q': secure_code})
    else:
        print("The input is not XSS injected code.")
        return jsonify({'result': 0})

if __name__ == '__main__':
    app.run(port=6000)