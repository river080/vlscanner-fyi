from flask import Flask,request,jsonify
from flask_restful import Resource, Api
from flask_cors import CORS
import numpy as np
import pandas as pd
import openai
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.metrics import accuracy_score, classification_report
import pickle as pkl
from sklearn.metrics import confusion_matrix
import os
from dotenv import load_dotenv

app = Flask("SQLAI")
cors = CORS(app, origins=['http://localhost:3000'])
api = Api(app)

load_dotenv()

api_key = os.getenv("openai_key")
openai.api_key = api_key

@app.route('/sqlai', methods=['POST'])
def aipredict():
    
    #Assigning dataset to variable named df(dataframe)
    df = pd.read_csv("SQLiV3.csv")

    #Unselect null coulmns
    df = df.iloc[:,:2]

    # Removing rows with null values
    df = df.dropna()

    # remove duplicate rows
    df.drop_duplicates(inplace = True)

    # Preprocess the text data using CountVectorizer
    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(df['Sentence'])
    
    # Load the saved model from a file
    with open('clf.pkl', 'rb') as f:
        clf_loaded = pkl.load(f)
    
    # Get the JSON data from the request
    data = request.get_json()
    query = data.get('query')

    # Vectorize the user input
    X_query = vectorizer.transform([query])

    # Use the loaded model to make a prediction
    y_pred = clf_loaded.predict(X_query)

    result  = y_pred[0]

    if result == '1':
        print("The input is a SQL injected query.")
        
        # Send the vulnerable SQL code to ChatGPT for recommendations
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-0301",
            messages=[
                {"role": "user", "content": f"There are potential SQL injection vulnerabilities in this code: {query}. How to make it secure. You must provide the answer in minimum words Do not include extra explanations, comments. Must provide the updated, more secure query. The answer must look like this, Recommendation: (your answer to the first question in minimum words), Query: (the secure query)"
                                 
                },
            ],
            max_tokens=45  # Adjust as needed
        )

        # Extract the recommendation and query from the ChatGPT response
        response_text = response['choices'][0]['message']['content']
        parts = response_text.split("Query:")

        if len(parts) == 2:
            recommendation = parts[0].strip()  # This should contain "Recommendation: Use parameterized queries."
            query = parts[1].strip()  # This should contain the secure query
        else:
            # Handle the case where the response doesn't follow the expected format
            recommendation = "Recommendation not found"
            query = "Query not found"

        # Now, you have the recommendation and query in separate variables
        # print(recommendation)
        # print(query)

        return jsonify({'result': 1, 'r':recommendation, 'q':query})
    else:
        print("The input is not a SQL injected query.")
        return jsonify({'result': 0})

if __name__ == '__main__':
    app.run()