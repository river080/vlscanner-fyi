//test.js
const qry = "select * from users"

const qry2 = " select * from users where id  =  1 ||1 union select 1,banner from v$version where rownum  =  1 -- 1"

// const qry5 = "select * from users where id  =  '1' or \.<\ union select 1,@@VERSION -- 1'"

const q = "SELECT * FROM products WHERE category = 'Gifts' AND released = 1"