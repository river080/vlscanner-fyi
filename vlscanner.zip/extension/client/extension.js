const vscode = require('vscode');
const detectSQLInjection = require('./rules/no_sql_injection');
const detectXSSInjection = require('./rules/no_xss');

// Define a diagnostic collection
const diagnosticCollection = vscode.languages.createDiagnosticCollection('securityVulnerabilities');

function activate(context) {
    console.log('Congratulations, your extension "vl-scanner" is now active!');

    // Register the command to manually scan code
    context.subscriptions.push(
        vscode.commands.registerCommand('vl-scanner.scanCode', async function () {
            scanActiveDocument();
        })
    );

    // Register the event handler to scan code on document save
    vscode.workspace.onDidSaveTextDocument((document) => {
        scanDocument(document);
    });
}

function scanActiveDocument() {
    const editor = vscode.window.activeTextEditor;
    if (editor) {
        const document = editor.document;
        scanDocument(document);
    }
}

async function scanDocument(document) {
    const text = document.getText();
    const sqlInjectionVulnerabilities = {
        'Sql Injection Vulnerability': await detectSQLInjection(text),
    };

    const xssVulnerabilities = {
        'XSS Vulnerability': await detectXSSInjection(text),
    };

    const allVulnerabilities = {
        ...sqlInjectionVulnerabilities,
        ...xssVulnerabilities,
    };

    // Display detected vulnerabilities as warnings
    displayVulnerabilitiesAsWarnings(document, allVulnerabilities);
}

function displayVulnerabilitiesAsWarnings(document, vulnerabilities) {
    // Create an array to store diagnostic entries
    const diagnosticEntries = [];

    for (const [vulnerabilityType, matches] of Object.entries(vulnerabilities)) {
        if (matches.length > 0) {
            matches.forEach(match => {
                // Create a diagnostic entry for the vulnerability
                const diagnostic = new vscode.Diagnostic(
                    new vscode.Range(match.lineNumber - 1, 0, match.lineNumber - 1, 0),
                    `${vulnerabilityType}\n${match.recommendation}\n\n${match.solution}`,
                    vscode.DiagnosticSeverity.Warning
                );
                diagnostic.source = '\nSecurity Vulnerability Checker';

                // Add the diagnostic entry to the array
                diagnosticEntries.push(diagnostic);
            });
        }
    }

    // Add the diagnostic entries to the collection for the current document
    diagnosticCollection.set(document.uri, diagnosticEntries);
}

function deactivate() {
    // Dispose of the diagnostic collection when the extension is deactivated
    diagnosticCollection.dispose();
}

module.exports = {
    activate,
    deactivate,
};
