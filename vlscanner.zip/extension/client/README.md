# Vl-Scanner

This is vl-scanner 1.0.0

![Vl-Scanner]

## Features

This extension helps to identify any sql, xss vulnerabilities in your codespace.
Ability to make your vulnerable code more secure using AI reccomendations.

## Requirements

Activate the extension in extension menu after installing. To run the extension, press Ctrl+LShift+P to open the extension search menu and select 'vl-scanner' command.

## Known Issues

The extension analyses only one three code lines per minute(As using a personal openai apikey). You may wait up to few seconds for the results to display. If you are having multiple lines of vulnerabilities in your code, you may run three(vulnerable) codelines at a time.

## Release Notes

This is the first release.

### 1.0.0

- Initial release.

## For more information

- [Visual Studio Code's Markdown Support](http://code.visualstudio.com/docs/languages/markdown)
- [Markdown Syntax Reference](https://help.github.com/articles/markdown-basics)

**Enjoy!**

