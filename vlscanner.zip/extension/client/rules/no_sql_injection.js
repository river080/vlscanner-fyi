const axios = require('axios');

module.exports = async function detectAndCheckSQLInjection(text) {
    const lines = text.split('\n');
    const sqlKeywords = [
        'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'FROM', 'WHERE',
        'UNION', 'DROP', 'EXEC', ';', '--', '\\|\\|', "'", '"', '%',
        '\\/\\*', '\\*\\/'
    ];

    const keywordRegex = new RegExp('\\b(' + sqlKeywords.join('|') + ')\\b', 'gi');

    const vulnerabilities = [];

    let inMultiLineComment = false;

    for (let lineNumber = 0; lineNumber < lines.length; lineNumber++) {
        const line = lines[lineNumber];
        
        // Check for the start of a multi-line comment (/*)
        if (line.includes('/*')) {
            inMultiLineComment = true;
        }
        
        // Check for the end of a multi-line comment (*/)
        if (line.includes('*/')) {
            inMultiLineComment = false;
        }
        
        // Skip lines that are entirely within a multi-line comment
        if (inMultiLineComment) {
            continue;
        }
        
        // Check for single-line comments in JavaScript, JSX, and Python
        if (line.trim().startsWith('//') || line.trim().startsWith('#')) {
            continue;
        }

        if (keywordRegex.test(line.toUpperCase())) {
            const query = line.trim();
            try {
                const response = await checkSQLInjection(query);
                if (response.data.result === 1) {
                    vulnerabilities.push({
                        query,
                        lineNumber: lineNumber + 1,
                        recommendation: response.data.r,
                        solution: response.data.q,
                    });
                }
            } catch (error) {
                console.error('Error checking SQL injection:', error);
            }
        }
    }

    return vulnerabilities;
}

async function checkSQLInjection(query) {
    try {
        const response = await axios.post('http://127.0.0.1:5000/sqlai', { query });
        return response;
    } catch (error) {
        console.error('Error sending the query to the Flask server:', error.message);
        throw error;
    }
}
