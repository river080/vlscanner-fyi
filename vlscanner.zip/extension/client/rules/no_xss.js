const axios = require('axios');

module.exports = async function detectAndCheckXSS(text) {
    const lines = text.split('\n');
    // Define XSS patterns to search for
    const xssPatterns = [
        'alert\\(', 'prompt\\(', 'confirm\\(', 'eval\\(', 'setTimeout\\(', 'setInterval\\(',
        'document\\.write\\(', 'innerHTML', 'escape', 'encodeURIComponent', 'encodeURI', 'unescape',
        '<script>', '</script>', '<img src=x onerror=alert(1)>', '<a href=javascript:alert(1)>',
        '<iframe src=javascript:alert(1)>', '<div onmouseover=alert(1)>',
        'onerror=', 'onload=', 'onmouseover=', 'onclick=', 'onfocus=', 'onblur=', 'onchange=',
        'onsubmit=', 'onloadend=', 'onreadystatechange=',
        'location\\.href', 'location\\.replace', 'location\\.assign'
    ];

    const xssRegex = new RegExp(xssPatterns.join('|'), 'gi');

    const vulnerabilities = [];

    let inMultiLineComment = false;

    for (let lineNumber = 0; lineNumber < lines.length; lineNumber++) {
        const line = lines[lineNumber];

        // Check for the start of a multi-line comment (/*)
        if (line.includes('/*')) {
            inMultiLineComment = true;
        }

        // Check for the end of a multi-line comment (*/)
        if (line.includes('*/')) {
            inMultiLineComment = false;
        }

        // Skip lines that are entirely within a multi-line comment
        if (inMultiLineComment) {
            continue;
        }

        // Check for single-line comments in JavaScript, JSX, and Python
        if (line.trim().startsWith('//') || line.trim().startsWith('#')) {
            continue;
        }

        // Check for JSX comments ({/* ... */})
        if (line.includes('{/*') && line.includes('*/}')) {
            continue;
        }

        if (xssRegex.test(line)) {
            const codeFragment = line.trim();
            try {
                const response = await checkXSSVulnerability(codeFragment);
                if (response.data.result === 1) {
                    vulnerabilities.push({
                        codeFragment,
                        lineNumber: lineNumber + 1,
                        recommendation: response.data.r,
                        solution: response.data.q,
                    });
                }
            } catch (error) {
                console.error('Error checking XSS injection:', error);
            }
        }
    }

    return vulnerabilities;
}

async function checkXSSVulnerability(codeFragment) {
    try {
        const response = await axios.post('http://127.0.0.1:6000/xssai', { codeFragment });
        return response;
    } catch (error) {
        console.error('Error sending the code fragment to the backend server:', error.message);
        return { data: { result: 0 } };
    }
}
